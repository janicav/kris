package tudelft.gettingstarted;

public class GettingStarted {
    public int addFive (int number) {
        return number + 5;
    }
}
