package tudelft.sum;

public class TwoNumbersSumTest {

}
